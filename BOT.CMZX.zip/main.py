import discord
from discord.ext import commands

# ===========================================
# CONFIGURAÇÕES DO BOT
# ===========================================
TOKEN = "SEU_TOKEN_AQUI"

# ---- CONFIGURAÇÕES DO SISTEMA DE AVISOS ----
GUILD_ID = 1446883370759094334
CARGO_AUTORIZADO_ID = 1446884011069673555  # quem pode usar /avisos

CARGOS_PERMITIDOS_AVISO = {
    "Marca todos": 1446888906032152686,
    "Ping Avisos": 1446912418142752801,
    "Ping comunidade": 1446912934042271795,
    "Ping Novidades": 1446913468220571831,
    "Ping Manutenção": 1446913634885439669,
    "Ping Eventos": 1446913797754191943,
    "Ping Video novo": 1446913923457618062,
    "Ping Sorteios": 1446914113522372829,
}

# ---- CONFIGURAÇÕES DO PAINEL DE PINGS ----
CANAL_PINGS_ID = 1446888906032152686
CANAL_MARCAR_EVERYONE = 1446888906032152686

PING_AVISOS = 1446912418142752801
PING_COMUNIDADE = 1446912934042271795
PING_NOVIDADES = 1446913468220571831
PING_MANUTENCAO = 1446913634885439669
PING_EVENTOS = 1446913797754191943
PING_VIDEO_NOVO = 1446913923457618062
PING_SORTEIOS = 1446914113522372829

EMOJIS = {
    "avisos": "⚠️",
    "comunidade": "💬",
    "novidades": "🆕",
    "manutencao": "🛠️",
    "eventos": "🎉",
    "video": "🎬",
    "sorteios": "🎁"
}

# ===========================================
# INICIALIZANDO BOT
# ===========================================
intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)


# ===========================================
# SISTEMA DE AVISOS (/avisos)
# ===========================================
class AvisoModal(discord.ui.Modal, title="Criar Aviso"):
    titulo = discord.ui.TextInput(
        label="Título do aviso",
        placeholder="Ex: Novo evento chegando!",
        required=True
    )
    conteudo = discord.ui.TextInput(
        label="Mensagem do aviso",
        style=discord.TextStyle.paragraph,
        placeholder="Escreva o conteúdo do aviso...",
        required=True
    )
    imagem = discord.ui.TextInput(
        label="Link da imagem (opcional)",
        required=False,
        placeholder="Cole o link da imagem"
    )

    async def on_submit(self, interaction):
        await interaction.response.send_message(
            "✅ Selecione abaixo o cargo que deseja mencionar:",
            view=AvisoCargoSelect(self.titulo.value, self.conteudo.value, self.imagem.value),
            ephemeral=True
        )


class AvisoCargoSelect(discord.ui.View):
    def __init__(self, titulo, conteudo, imagem):
        super().__init__(timeout=60)
        self.titulo = titulo
        self.conteudo = conteudo
        self.imagem = imagem

        select = discord.ui.Select(
            placeholder="📌 Selecione o cargo para mencionar",
            min_values=1,
            max_values=1,
            options=[
                discord.SelectOption(label=nome, value=str(cargo_id))
                for nome, cargo_id in CARGOS_PERMITIDOS_AVISO.items()
            ]
        )

        select.callback = self.callback
        self.add_item(select)

    async def callback(self, interaction):
        cargo_id = int(interaction.data["values"][0])
        cargo = interaction.guild.get_role(cargo_id)

        embed = discord.Embed(
            title=self.titulo,
            description=self.conteudo,
            color=discord.Color.blue()
        )

        await interaction.response.send_message(
            content=cargo.mention if cargo else "",
            embed=embed,
            allowed_mentions=discord.AllowedMentions(roles=True),
        )


@bot.tree.command(
    name="avisos",
    description="Cria um aviso personalizado em embed",
    guild=discord.Object(id=GUILD_ID)   # 👈 FORÇA A APARECER IMEDIATO
)
async def avisos_cmd(interaction):
    cargo_autorizado = interaction.guild.get_role(CARGO_AUTORIZADO_ID)

    if cargo_autorizado not in interaction.user.roles:
        return await interaction.response.send_message(
            "🚫 Você não tem permissão para usar esse comando!",
            ephemeral=True
        )

    await interaction.response.send_modal(AvisoModal())


# ===========================================
# PAINEL DE PINGS
# ===========================================
def criar_embed():
    embed = discord.Embed(
        title="Pings Disponíveis:",
        description="Clique no emoji para receber o cargo.\nClique novamente para remover.",
        color=discord.Color.blue()
    )

    embed.add_field(name=f"{EMOJIS['avisos']} Ping Avisos", value=f"<@&{PING_AVISOS}>", inline=False)
    embed.add_field(name=f"{EMOJIS['comunidade']} Ping Comunidade", value=f"<@&{PING_COMUNIDADE}>", inline=False)
    embed.add_field(name=f"{EMOJIS['novidades']} Ping Novidades", value=f"<@&{PING_NOVIDADES}>", inline=False)
    embed.add_field(name=f"{EMOJIS['manutencao']} Ping Manutenção", value=f"<@&{PING_MANUTENCAO}>", inline=False)
    embed.add_field(name=f"{EMOJIS['eventos']} Ping Eventos", value=f"<@&{PING_EVENTOS}>", inline=False)
    embed.add_field(name=f"{EMOJIS['video']} Ping Vídeo Novo", value=f"<@&{PING_VIDEO_NOVO}>", inline=False)
    embed.add_field(name=f"{EMOJIS['sorteios']} Ping Sorteios", value=f"<@&{PING_SORTEIOS}>", inline=False)

    return embed


# ===========================================
# ON_READY
# ===========================================
@bot.event
async def on_ready():
    print(f"🤖 Bot online como {bot.user}!")

    # SINCRONIZAÇÃO GARANTIDA
    guild = discord.Object(id=GUILD_ID)
    await bot.tree.sync(guild=guild)
    print("✅ Slash commands sincronizados!")

    canal = bot.get_channel(CANAL_PINGS_ID)
    painel_existente = None

    async for msg in canal.history(limit=20):
        if msg.author == bot.user and msg.embeds:
            if msg.embeds[0].title == "Pings Disponíveis:":
                painel_existente = msg
                break

    if not painel_existente:
        embed = criar_embed()
        painel = await canal.send("@everyone", embed=embed)
        for emoji in EMOJIS.values():
            await painel.add_reaction(emoji)

    print("Painel OK!")


# ===========================================
# ADICIONAR / REMOVER CARGOS POR REAÇÃO
# ===========================================
@bot.event
async def on_raw_reaction_add(payload):
    if payload.channel_id != CANAL_PINGS_ID:
        return

    guild = bot.get_guild(payload.guild_id)
    member = guild.get_member(payload.user_id)

    if not member or member.bot:
        return

    roles = {
        EMOJIS["avisos"]: PING_AVISOS,
        EMOJIS["comunidade"]: PING_COMUNIDADE,
        EMOJIS["novidades"]: PING_NOVIDADES,
        EMOJIS["manutencao"]: PING_MANUTENCAO,
        EMOJIS["eventos"]: PING_EVENTOS,
        EMOJIS["video"]: PING_VIDEO_NOVO,
        EMOJIS["sorteios"]: PING_SORTEIOS
    }

    emoji = str(payload.emoji)
    if emoji in roles:
        role = guild.get_role(roles[emoji])
        await member.add_roles(role)


@bot.event
async def on_raw_reaction_remove(payload):
    if payload.channel_id != CANAL_PINGS_ID:
        return

    guild = bot.get_guild(payload.guild_id)
    member = guild.get_member(payload.user_id)

    if not member or member.bot:
        return

    roles = {
        EMOJIS["avisos"]: PING_AVISOS,
        EMOJIS["comunidade"]: PING_COMUNIDADE,
        EMOJIS["novidades"]: PING_NOVIDADES,
        EMOJIS["manutencao"]: PING_MANUTENCAO,
        EMOJIS["eventos"]: PING_EVENTOS,
        EMOJIS["video"]: PING_VIDEO_NOVO,
        EMOJIS["sorteios"]: PING_SORTEIOS
    }

    emoji = str(payload.emoji)
    if emoji in roles:
        role = guild.get_role(roles[emoji])
        await member.remove_roles(role)


# ===========================================
# AUTO @EVERYONE
# ===========================================
@bot.event
async def on_message(message):
    if not message.author.bot and message.channel.id == CANAL_MARCAR_EVERYONE:
        await message.channel.send("@everyone")

    await bot.process_commands(message)


# ===========================================
# INICIAR BOT
# ===========================================
bot.run("MTQ0NjkxMDM5NTMyMjMzOTU4MA.GzYcrN.PtJu14PJ_zX4BlKPY-2WjjSdadFf2rbtEa7IcY")

